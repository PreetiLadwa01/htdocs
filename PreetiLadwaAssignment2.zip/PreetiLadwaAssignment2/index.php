<!DOCTYPE html>
<html>
<head>
<title>Assignment 03</title>
</head>

<body>

<h1>Enter a list of five number</h1>
<form method="post" action="results.php"> 

 <label for="num1">First Number</label><br>
  <input type="number" id="num1" name="num1"><br>

  <label for="num2">Second Number:</label><br>
  <input type="number" id="num2" name="num2"><br>

  <label for="num3">Third Number:</label><br>
  <input type="number" id="num3" name="num3"><br>

  <label for="num4">Fourth Number:</label><br>
  <input type="number" id="num4" name="num4"><br>

  <label for="num5">Fifth Number:</label><br>
  <input type="number" id="num5" name="num5"><br>

 <input type="submit" value="Submit"/>

</form>
</body>
</html>
